var input = document.getElementById("tUrl");
var output = document.getElementById("output")

const form = document.querySelector('form');
var goUrl = "home.html"

form.addEventListener('submit', async event => {
    event.preventDefault();
    window.navigator.serviceWorker.register('./sw.js', {
        scope: __uv$config.prefix
    }).then(() => {
        let url = input.value.trim();
        if (!isUrl(url)) url = 'https://www.google.com/search?q=' + url;
        else if (!(url.startsWith('https://') || url.startsWith('http://'))) url = 'http://' + url;

      goUrl = output.src
      output.src = __uv$config.prefix + __uv$config.encodeUrl(url);
      
    });
});

function isUrl(val = ''){
    if (/^http(s?):\/\//.test(val) || val.includes('.') && val.substr(0, 1) !== ' ') return true;
    return false;
};
var g;
function bac(){
  g = output.src;
  output.src= goUrl;
  
}
function fwd(){
  goUrl = output.src
  output.src = g;
}
function relo(){
  output.src= output.src
}

function fillUrl(txt){
  input.value=txt
  window.navigator.serviceWorker.register('./sw.js', {
        scope: __uv$config.prefix
    }).then(() => {
        let url = input.value.trim();
        if (!isUrl(url)) url = 'https://www.google.com/search?q=' + url;
        else if (!(url.startsWith('https://') || url.startsWith('http://'))) url = 'http://' + url;

      goUrl = output.src
      output.src = __uv$config.prefix + __uv$config.encodeUrl(url);
      
    });
}

if ("serviceWorker" in navigator) {
  window.addEventListener("load", function() {
    navigator.serviceWorker
      .register("/serviceWorker.js")
      .then(res => console.log("service worker registered"))
      .catch(err => console.log("service worker not registered", err))
  })
}